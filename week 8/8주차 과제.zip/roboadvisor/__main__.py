#!/usr/bin/env python
# coding: utf-8

# In[3]:


from analysis.series import series_test
from crawling.parser import parser_test

if __name__ == '__main__':
    series_test()
    parser_test()


# In[ ]:




