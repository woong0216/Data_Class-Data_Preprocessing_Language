#!/usr/bin/env python
# coding: utf-8

# In[2]:


def scrap_test():
    print("scrap")

