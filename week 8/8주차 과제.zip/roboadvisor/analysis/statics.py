#!/usr/bin/env python
# coding: utf-8

# In[2]:


def staics_test():
    print("statics")

