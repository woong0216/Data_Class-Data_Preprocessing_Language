#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from . import series
from . import statics

__all__ = ['series', 'statics']
